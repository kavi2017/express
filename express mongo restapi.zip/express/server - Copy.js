import express from 'express';
const app = express();
const port = process.env.PORT || 5656;
import bookRouter from './Routes/bookRouter';
const util = require('util')
import bodyParser from 'body-parser';

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// routes go here
app.listen(port, () => {
    console.log(`http://localhost:${port}`)
})
import mongoose from 'mongoose';
const db = mongoose.connect('mongodb://localhost:27017/college', { useNewUrlParser: true });


app.use('/api/Books', bookRouter);
app.use('/api/Books/id', bookRouter);

/* var MongoClient = require('mongodb').MongoClient;

var uri = "mongodb://kavi:kOqb9jagjvMxmO3t@clusterkavi-shard-00-00-brcoj.mongodb.net:27017,clusterkavi-shard-00-01-brcoj.mongodb.net:27017,clusterkavi-shard-00-02-brcoj.mongodb.net:27017/test?ssl=true&replicaSet=Clusterkavi-shard-0&authSource=admin&retryWrites=true&w=majority";
MongoClient.connect(uri, function(err, client) {
  const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  client.close();
});
 */
/* 
const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://kavi:kOqb9jagjvMxmO3t@clusterkavi-brcoj.mongodb.net/test?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(err => {
  const collection = client.db("test").collection("devices");
  // perform actions on the collection object
  client.close();
});
 */
var MongoClient = require('mongodb').MongoClient;
//MongoClient.connect('mongodb://localhost:27017/admin', { useNewUrlParser: true })

// Connect to the db
/* MongoClient.connect("mongodb://localhost:27017/admin", function (err, db) {
   
     if(err) console.log(err,'error');
	//console.log(util.inspect(db, {showHidden: false, depth: null}))
	
     //Write databse Insert/Update/Query code here..
	 db.collection('Persons', function (err, collection) {
        
        collection.insert({ id: 1, firstName: 'Steve', lastName: 'Jobs' });
        collection.insert({ id: 2, firstName: 'Bill', lastName: 'Gates' });
        collection.insert({ id: 3, firstName: 'James', lastName: 'Bond' });
        
        

        db.collection('Persons').count(function (err, count) {
            if (err) throw err;
            
            console.log('Total Rows: ' + count);
        });
    });
	 db.collection('Persons', function (err, collection) {
        
         collection.find().toArray(function(err, items) {
            if(err) throw err;    
            console.log(items);            
        });
        
    });           
}); */
/* app.get('/api/books', (req, res) => {
    res.json([
            {
                id: 1,
                title: "Alice's Adventures in Wonderland",
                author: "Charles Lutwidge Dodgson"
            },
            {
                id: 2,
                title: "Einstein's Dreams",
                author: "Alan Lightman"
            }
        ])
})
app.get('/api/books/2', (req,res)=>{
    res.json(
            {
                id: 2,
                title: "Einstein's Dreams",
                author: "Alan Lightman"
            }
        )
}) */