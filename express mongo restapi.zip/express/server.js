import express from 'express';
const app = express();
const port = process.env.PORT || 2000;
import studentRouter from './Routes/studentRouter';
import bodyParser from 'body-parser';

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// routes go here
app.listen(port, () => {
    console.log(`http://localhost:${port}`)
})
import mongoose from 'mongoose';
const db = mongoose.connect('mongodb://localhost:27017/college', { useNewUrlParser: true });

app.use('/api/Students', studentRouter);
app.use('/api/Students/login', studentRouter);
app.use('/api/Students/signUp', studentRouter);
app.use('/api/Students/id', studentRouter);
app.use('/api/Students/type/id', studentRouter);
