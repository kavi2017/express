import express from 'express';
import Book from '../models/bookModel';
const bookRouter = express.Router();
/* bookRouter
    .get('/', (req,res) => {
        res.json([
            {
                id: 1,
                title: "Alice's Adventures in Wonderland",
                author: "Charles Lutwidge Dodgson"
            },
            {
                id: 2,
                title: "Einstein's Dreams",
                author: "Alan Lightman"
            }
        ])
    })
    .get('/2', (req,res) => {
		console.log(req.params);
         res.json(
            {
                id: 2,
                title: "Einstein's Dreams",
                author: "Alan Lightman"
            }
        )
    }) */
	
bookRouter.route('/')
.get((req, res) => {
	Book.find({}, (err, books) => {
		res.json(books)
	})  
})
/* .post((req, res) => {
        let book = new Book({title: 'The Bull', author: 'Saki'});
        book.save();
        res.status(201).send(book) 
    }) */
	.post((req,res) => {
        let book = new Book(req.body); // edited line
        book.save()
        res.status(201).send(book)
    })
	
bookRouter.route('/:bookId')
    .get((req, res) => {
        Book.findById(req.params.bookId, (err, book) => {
            res.json(book)
        })  
    })
	// edit the book data 
	.put((req,res) => {
        Book.findById(req.params.bookId, (err, book) => {
			if(err) res.json({status:0, StatusInfo: err})
            book.title = req.body.title;
            book.author = req.body.author;
            book.save()
            res.json(book)
        }) 
    })
	// PATCH will allow users to edit specific properties of a book object. This is still attached to bookRouter.route('/:bookId'). 
	// We pull the particular book from the database and modify all the properties that match the incoming information
	.patch((req,res)=>{
        Book.findById(req.params.bookId, (err, book) => {
			if(err) res.json({status:0, StatusInfo: err})
            if(req.body._id){
                delete req.body._id;
            }
            for( let b in req.body ){
                book[b] = req.body[b];
            }
            book.save();
            res.json(book);
        })
    })

export default bookRouter;


