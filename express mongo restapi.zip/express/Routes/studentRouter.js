import express from 'express';
import Student from '../models/studentModel';
const studentRouter = express.Router();

studentRouter.route('/')
// student list
.get((req, res) => {
	Student.find({}, (err, Students) => {
		res.json(Students)
	})  
})
// signup - register student
studentRouter.route('/signUp')
	.post((req,res) => {
        let student = new Student(req.body); // edited line
        //student.save()
		var new_user = new Student({
			firstName: req.body.firstName,
			lastName: req.body.lastName,
			email: req.body.email,
			mobileno: req.body.mobileno,
		});

		new_user.password = new_user.generateHash(req.body.password);
		new_user.save();
		res.status(201).send(new_user)

		
    })
	// type 
studentRouter.route('/Type/:id')
	.post((req,res) => {
		console.log(req.body)
		// if type is 1
		if(req.params.id == 1) {
		var array = req.body;
		var arrayLen = array.length;
    	var v1 = [];
		 var v2 = [];
		for(var i=0; i<arrayLen; i++)
		if(array[i] % 2 == 0)
			v1.push(array[i])
		else 
			v2.push(array[i])	
		
	
		v1.sort(function(a, b) { 
			return a - b; 
		})
		v2.sort(function(a, b) { 
			return b - a; 
		})
		console.log(v1, v2)
		var index = 0; 
		var i = 0; 
		var j = 0; 
		var flag = false;  
		// Set flag to true if first element is even  
		if (array[0] % 2 == 0)  
			flag = true;  
		// Start rearranging array  
		while (index < arrayLen)  
		{  
	  
			// If first element is even  
			if (flag == true)  
			{  
				array[index++] = v1[i++];  
				flag = !flag;  
			}  
	  
			// Else, first element is Odd  
			else 
			{  
				array[index++] = v2[j++];  
				flag = !flag;  
			}  
		}  
			res.json(array)
		// if type is 2
		} else if(req.params.id == 2) {
			var stringIn = req.body.a;
			console.log(stringIn)
			var rev = stringIn.replace(/[a-z]+/gi, function(s){return s.split('').reverse().join('')});
			// Initialize left and right pointers 
			res.json(rev)
		// if type 3 	
		} else if(req.params.id == 3) {
			var array = req.body;
			var mia = array.reduce(function(acc, cur, ind, arr) {
			  var diff = cur - arr[ind-1];
			  if (diff > 1) {
				var i = 1;
				while (i < diff) {
				  acc.push(arr[ind-1]+i);
				  i++;
				}
			  }
			  return acc;
			}, []);
			res.json(mia)
		} else {
			res.json([]);
		}
		
    })
	
studentRouter.route('/:StudentId')
    .get((req, res) => {
        Student.findById(req.params.StudentId, (err, student) => {
            res.json(student)
        })  
    })
	// edit the Student data 
	.put((req,res) => {
        Student.findById(req.params.studentId, (err, student) => {
			if(err) res.json({status:0, StatusInfo: err})
            student.title = req.body.title;
            student.author = req.body.author;
            student.save()
            res.json(student)
        }) 
    })

studentRouter.post('/login', function(req, res) {
  Student.findOne({email: req.body.email}, function(err, student) {
	
    if (!student.validPassword(req.body.password)) {
      //password did not match
	  res.json({status:0, statusMsg:"The student email and password does not match"})
    } else {
      // password matched. proceed forward
	  res.json({status:1, statusMsg:"The student email and password are match"})
    }
  });
});

export default studentRouter;


